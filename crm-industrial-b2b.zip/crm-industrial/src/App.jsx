import { useState, useEffect, useRef } from "react";

const STAGES = [
  { id: "prospeccao",   label: "Prospecção",  tag: "S1",   color: "#888780" },
  { id: "qualificacao", label: "Qualificação",tag: "S2",   color: "#185FA5" },
  { id: "diagnostico",  label: "Diagnóstico", tag: "S2+",  color: "#378ADD" },
  { id: "proposta",     label: "Proposta",    tag: "S3",   color: "#BA7517" },
  { id: "negociacao",   label: "Negociação",  tag: "NEG",  color: "#D85A30" },
  { id: "fechamento",   label: "Fechamento",  tag: "FECH", color: "#639922" },
  { id: "pos_venda",    label: "Pós-Venda",   tag: "M",    color: "#0F6E56" },
];

const DEMO = [
  { id:"1", title:"MES NOMUDA — linha de montagem", company:"Honda", contact:"Eng. Carlos Mota", value:180000, stage:"diagnostico", priority:"alta", nextAction:"Apresentar demo NOMUDA na planta", nextDate:"2026-04-20", notes:"Interesse em rastreabilidade de torque. Linha atual sem MES.", history:[], createdAt:"2026-04-10" },
  { id:"2", title:"Tecnologia de aperto linha chassis", company:"Caterpillar", contact:"Dir. Paulo Reis", value:320000, stage:"proposta", priority:"alta", nextAction:"Enviar proposta com análise Cp/Cpk", nextDate:"2026-04-18", notes:"Engenharia aprovou spec. Compras aguarda aprovação.", history:[], createdAt:"2026-04-05" },
  { id:"3", title:"Sistema supervisório + SCADA", company:"Jacto", contact:"Eng. Ana Lima", value:95000, stage:"qualificacao", priority:"media", nextAction:"Visita técnica ao chão de fábrica", nextDate:"2026-04-25", notes:"Migração de sistema legado.", history:[], createdAt:"2026-04-12" },
  { id:"4", title:"Implantação MES NOMUDA completo", company:"Rumo", contact:"Ger. Roberto Nunes", value:210000, stage:"negociacao", priority:"alta", nextAction:"Reunião de negociação com diretoria", nextDate:"2026-04-17", notes:"Concorrente Atlas no jogo.", history:[], createdAt:"2026-03-28" },
  { id:"5", title:"Ferramentas de aperto pneumáticas", company:"Baldan", contact:"Comp. Marcos Silva", value:42000, stage:"prospeccao", priority:"baixa", nextAction:"Cold call para agendar visita", nextDate:"2026-04-30", notes:"Indicação via Jacto.", history:[], createdAt:"2026-04-14" },
  { id:"6", title:"Integração MES + ERP SAP", company:"Electrolux", contact:"Dir. TI Fernanda Costa", value:155000, stage:"fechamento", priority:"alta", nextAction:"Assinar contrato e definir kick-off", nextDate:"2026-04-19", notes:"Aprovação confirmada. Aguarda assinatura jurídica.", history:[], createdAt:"2026-03-20" },
];

const PRI_BG  = { alta:"#FCEBEB", media:"#FAEEDA", baixa:"#EAF3DE" };
const PRI_TXT = { alta:"#791F1F", media:"#633806", baixa:"#27500A" };

const SYS = `Você é o Gestor Comercial IA de uma empresa B2B industrial brasileira especializada em:
- Tecnologia de aperto (torque, ângulo, TTA, Open Protocol, Atlas Copco, Ingersoll Rand, Desoutter, Cleco)
- MES NOMUDA (rastreabilidade, OEE, integração ERP, gestão de torque, qualidade)
- Sistemas industriais: Chão de Fábrica → Supervisório → SCADA → MES → ERP
- Clientes: Caterpillar, Honda, Hyundai, GWM Brasil, Rumo, Baldan, Electrolux, Jacto, Brudden, MP Agro, Piccin

Metodologias que você domina:
- 3S+M (Triplo SM): Suspect → Suspect Qualificado → Solução → Manutenção (7 passos de compra/venda)
- 5W2H: What, Why, Who, Where, When, How, How much
- Kaizen aplicado ao desenvolvimento de clientes

Responda em português brasileiro. Seja direto, prático e específico. Máx 180 palavras. Use bullets para ações.`;

const STORAGE_KEY = "crm_industrial_v1";

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function persist(data) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch {}
}

export default function App() {
  const [opps, setOpps]           = useState(() => load() || DEMO);
  const [sel, setSel]             = useState(null);
  const [view, setView]           = useState("kanban");
  const [aiOpen, setAiOpen]       = useState(false);
  const [aiMsgs, setAiMsgs]       = useState([]);
  const [aiInput, setAiInput]     = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [apiKey, setApiKey]       = useState(() => localStorage.getItem("crm_api_key") || "");
  const [showKey, setShowKey]     = useState(false);
  const [newModal, setNewModal]   = useState(false);
  const [form, setForm]           = useState({ title:"", company:"", contact:"", value:"", stage:"prospeccao", priority:"media", nextAction:"", nextDate:"", notes:"" });
  const aiEnd = useRef(null);

  useEffect(() => { persist(opps); }, [opps]);
  useEffect(() => { aiEnd.current?.scrollIntoView({ behavior:"smooth" }); }, [aiMsgs]);

  function saveKey(k) {
    setApiKey(k);
    localStorage.setItem("crm_api_key", k);
  }

  function updateOpp(updated) {
    setOpps(prev => prev.map(o => o.id === updated.id ? updated : o));
    setSel(updated);
  }

  function move(id, dir) {
    const opp = opps.find(o => o.id === id);
    const idx = STAGES.findIndex(s => s.id === opp.stage);
    const next = idx + dir;
    if (next < 0 || next >= STAGES.length) return;
    const updated = { ...opp, stage: STAGES[next].id };
    setOpps(prev => prev.map(o => o.id === id ? updated : o));
    setSel(updated);
  }

  function addOpp() {
    if (!form.title || !form.company) return;
    const o = { ...form, id: Date.now().toString(), value: Number(form.value)||0, history:[], createdAt: new Date().toISOString().slice(0,10) };
    setOpps(prev => [...prev, o]);
    setNewModal(false);
    setForm({ title:"", company:"", contact:"", value:"", stage:"prospeccao", priority:"media", nextAction:"", nextDate:"", notes:"" });
  }

  function delOpp(id) {
    setOpps(prev => prev.filter(o => o.id !== id));
    setSel(null);
  }

  function exportData() {
    const blob = new Blob([JSON.stringify(opps, null, 2)], { type:"application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "crm-backup.json"; a.click();
    URL.revokeObjectURL(url);
  }

  function importData(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target.result);
        if (Array.isArray(data)) { setOpps(data); alert("Dados importados!"); }
      } catch { alert("Arquivo inválido."); }
    };
    reader.readAsText(file);
  }

  async function chat(msg) {
    const m = msg || aiInput;
    if (!m.trim() || aiLoading) return;
    if (!apiKey) { setShowKey(true); return; }
    const ctx = sel
      ? `Oportunidade: "${sel.title}" | Empresa: ${sel.company} | Etapa: ${STAGES.find(s=>s.id===sel.stage)?.label} | Valor: R$ ${sel.value?.toLocaleString("pt-BR")} | Próxima ação: ${sel.nextAction} | Notas: ${sel.notes}`
      : "Nenhuma oportunidade selecionada.";
    const full = `${m}\n\nContexto: ${ctx}`;
    const msgs = [...aiMsgs, { role:"user", content: m }];
    setAiMsgs(msgs);
    setAiInput("");
    setAiLoading(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{ "Content-Type":"application/json", "x-api-key": apiKey, "anthropic-version":"2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514",
          max_tokens:1000,
          system: SYS,
          messages: [...msgs.slice(0,-1), { role:"user", content: full }]
        })
      });
      const d = await res.json();
      if (d.error) throw new Error(d.error.message);
      const reply = d.content?.map(c=>c.text||"").join("") || "Sem resposta.";
      setAiMsgs([...msgs, { role:"assistant", content: reply }]);
    } catch(err) {
      setAiMsgs([...msgs, { role:"assistant", content:`Erro: ${err.message}` }]);
    }
    setAiLoading(false);
  }

  function openAI(prompt) {
    setAiOpen(true);
    if (!apiKey) { setShowKey(true); return; }
    if (aiMsgs.length === 0) setAiMsgs([{ role:"assistant", content:"Olá! Sou seu Gestor IA. Selecione uma oportunidade e me pergunte sobre próximos passos, argumentos NOMUDA, torque, 3S+M, 5W2H ou Kaizen." }]);
    if (prompt) setTimeout(() => chat(prompt), 150);
  }

  const today    = new Date().toISOString().slice(0,10);
  const totalVal = opps.reduce((s,o)=>s+(o.value||0),0);
  const wonVal   = opps.filter(o=>o.stage==="pos_venda").reduce((s,o)=>s+(o.value||0),0);
  const overdue  = opps.filter(o=>o.nextDate && o.nextDate<today).length;
  const highPri  = opps.filter(o=>o.priority==="alta").length;

  const S = {
    root:   { fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif", color:"#1a1a1a", background:"#f5f5f3", minHeight:"100vh" },
    hdr:    { background:"#fff", borderBottom:"1px solid #e8e8e8", padding:"10px 16px", display:"flex", alignItems:"center", gap:"10px", flexWrap:"wrap", position:"sticky", top:0, zIndex:10 },
    metBar: { background:"#fff", borderBottom:"1px solid #e8e8e8", padding:"8px 16px", display:"flex", gap:"20px", flexWrap:"wrap" },
    body:   { padding:"12px 16px", display:"flex", gap:"12px", alignItems:"flex-start" },
    card:   { background:"#fff", border:"1px solid #e8e8e8", borderRadius:"8px", padding:"14px" },
    input:  { width:"100%", fontSize:"12px", padding:"6px 9px", borderRadius:"6px", border:"1px solid #ddd", background:"#fafafa", color:"#1a1a1a", boxSizing:"border-box" },
    label:  { fontSize:"11px", color:"#888", marginBottom:"3px", textTransform:"uppercase", letterSpacing:"0.05em" },
    btn:    (bg,tc,bc) => ({ padding:"6px 12px", fontSize:"12px", borderRadius:"6px", border:`1px solid ${bc||bg}`, background:bg, color:tc, cursor:"pointer", fontWeight:500 }),
  };

  return (
    <div style={S.root}>
      {/* HEADER */}
      <div style={S.hdr}>
        <div style={{display:"flex",alignItems:"center",gap:"8px",flex:1,minWidth:"180px"}}>
          <div style={{width:"28px",height:"28px",borderRadius:"6px",background:"#185FA5",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="1" y="1" width="5" height="5" rx="1" fill="#E6F1FB"/><rect x="8" y="1" width="5" height="5" rx="1" fill="#E6F1FB"/><rect x="1" y="8" width="5" height="5" rx="1" fill="#E6F1FB"/><rect x="8" y="8" width="5" height="5" rx="1" fill="#85B7EB"/></svg>
          </div>
          <span style={{fontWeight:600,fontSize:"15px"}}>CRM Industrial B2B</span>
          <span style={{fontSize:"10px",padding:"2px 8px",borderRadius:"10px",background:"#E6F1FB",color:"#0C447C",fontWeight:600}}>3S+M</span>
        </div>
        <div style={{display:"flex",gap:"4px"}}>
          {[["kanban","Pipeline"],["dashboard","Funil"],["tasks","Follow-ups"]].map(([v,l])=>(
            <button key={v} onClick={()=>setView(v)} style={{padding:"5px 11px",fontSize:"12px",borderRadius:"6px",border:"1px solid",borderColor:view===v?"#185FA5":"#ddd",background:view===v?"#E6F1FB":"transparent",color:view===v?"#0C447C":"#666",cursor:"pointer",fontWeight:view===v?600:400}}>{l}</button>
          ))}
        </div>
        <button onClick={()=>setNewModal(true)} style={S.btn("#E1F5EE","#085041","#0F6E56")}>+ Nova oportunidade</button>
        <button onClick={()=>openAI(null)} style={S.btn("#EEEDFE","#3C3489","#534AB7")}>Gestor IA</button>
        <button onClick={exportData} style={S.btn("#f5f5f3","#555","#ddd")} title="Exportar backup JSON">↓ Backup</button>
        <label style={{...S.btn("#f5f5f3","#555","#ddd"),cursor:"pointer"}} title="Importar dados">
          ↑ Importar
          <input type="file" accept=".json" onChange={importData} style={{display:"none"}}/>
        </label>
        <button onClick={()=>setShowKey(true)} style={{...S.btn("#f5f5f3","#555","#ddd"), fontSize:"11px"}} title="Configurar chave da API">⚙ API Key</button>
      </div>

      {/* MÉTRICAS */}
      <div style={S.metBar}>
        {[
          {l:"Pipeline total",  v:`R$ ${(totalVal/1000).toFixed(0)}k`},
          {l:"Em pós-venda",    v:`R$ ${(wonVal/1000).toFixed(0)}k`},
          {l:"Oportunidades",   v:opps.length},
          {l:"Alta prioridade", v:highPri, warn:highPri>0},
          {l:"Atrasados",       v:overdue, warn:overdue>0},
        ].map((m,i)=>(
          <div key={i} style={{display:"flex",gap:"5px",alignItems:"baseline"}}>
            <span style={{fontSize:"15px",fontWeight:600,color:m.warn?"#E24B4A":"#1a1a1a"}}>{m.v}</span>
            <span style={{fontSize:"11px",color:"#888"}}>{m.l}</span>
          </div>
        ))}
      </div>

      {/* CONTEÚDO */}
      <div style={S.body}>

        {/* ── KANBAN ── */}
        {view==="kanban" && (
          <div style={{flex:1,overflowX:"auto"}}>
            <div style={{display:"flex",gap:"8px",paddingBottom:"8px",minWidth:"max-content"}}>
              {STAGES.map(stage=>{
                const cols = opps.filter(o=>o.stage===stage.id);
                const colVal = cols.reduce((s,o)=>s+(o.value||0),0);
                return (
                  <div key={stage.id} style={{width:"196px",flexShrink:0}}>
                    <div style={{display:"flex",alignItems:"center",gap:"5px",marginBottom:"6px"}}>
                      <span style={{fontSize:"10px",fontWeight:600,padding:"2px 7px",borderRadius:"10px",background:stage.color+"22",color:stage.color}}>{stage.tag}</span>
                      <span style={{fontSize:"12px",fontWeight:600,flex:1}}>{stage.label}</span>
                      <span style={{fontSize:"11px",color:"#aaa"}}>{cols.length}</span>
                    </div>
                    {colVal>0 && <div style={{fontSize:"11px",color:"#aaa",marginBottom:"5px"}}>R$ {(colVal/1000).toFixed(0)}k</div>}
                    <div style={{display:"flex",flexDirection:"column",gap:"6px",minHeight:"60px"}}>
                      {cols.map(opp=>(
                        <div key={opp.id} onClick={()=>setSel(opp===sel?null:opp)}
                          style={{background:"#fff",border:`1px solid ${sel?.id===opp.id?stage.color:"#e8e8e8"}`,borderLeft:`3px solid ${stage.color}`,borderRadius:"0 8px 8px 0",padding:"10px 10px 10px 9px",cursor:"pointer",transition:"border-color .15s"}}>
                          <div style={{fontSize:"12px",fontWeight:600,marginBottom:"3px",lineHeight:1.3}}>{opp.title}</div>
                          <div style={{fontSize:"11px",color:"#666",marginBottom:"7px"}}>{opp.company}</div>
                          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                            <span style={{fontSize:"12px",fontWeight:600}}>R$ {(opp.value/1000).toFixed(0)}k</span>
                            <span style={{fontSize:"10px",padding:"2px 6px",borderRadius:"8px",background:PRI_BG[opp.priority],color:PRI_TXT[opp.priority],fontWeight:600}}>{opp.priority}</span>
                          </div>
                          {opp.nextDate && opp.nextDate<today && <div style={{fontSize:"10px",color:"#E24B4A",marginTop:"5px",fontWeight:600}}>Atrasado · {opp.nextDate}</div>}
                          {opp.nextAction && <div style={{fontSize:"10px",color:"#aaa",marginTop:"3px",lineHeight:1.3}}>{opp.nextAction.slice(0,50)}{opp.nextAction.length>50?"…":""}</div>}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── FUNIL ── */}
        {view==="dashboard" && (
          <div style={{flex:1}}>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))",gap:"8px",marginBottom:"14px"}}>
              {STAGES.map(s=>{
                const count = opps.filter(o=>o.stage===s.id).length;
                const val   = opps.filter(o=>o.stage===s.id).reduce((a,o)=>a+o.value,0);
                const pct   = totalVal>0 ? Math.round(val/totalVal*100) : 0;
                return (
                  <div key={s.id} style={{background:"#fff",border:"1px solid #e8e8e8",borderRadius:"8px",padding:"12px",borderTop:`3px solid ${s.color}`}}>
                    <div style={{fontSize:"10px",color:"#aaa",marginBottom:"4px"}}>{s.tag} · {s.label}</div>
                    <div style={{fontSize:"22px",fontWeight:600,marginBottom:"2px"}}>{count}</div>
                    <div style={{fontSize:"11px",color:"#888"}}>R$ {(val/1000).toFixed(0)}k · {pct}%</div>
                  </div>
                );
              })}
            </div>
            <div style={S.card}>
              <div style={{fontSize:"12px",fontWeight:600,marginBottom:"10px"}}>Todas as oportunidades</div>
              {[...opps].sort((a,b)=>b.value-a.value).map(opp=>(
                <div key={opp.id} onClick={()=>{setSel(opp);setView("kanban");}} style={{display:"flex",alignItems:"center",gap:"10px",padding:"8px 0",borderBottom:"1px solid #f0f0f0",cursor:"pointer"}}>
                  <div style={{width:"8px",height:"8px",borderRadius:"50%",background:STAGES.find(s=>s.id===opp.stage)?.color,flexShrink:0}}/>
                  <span style={{fontSize:"12px",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{opp.title}</span>
                  <span style={{fontSize:"11px",color:"#888",minWidth:"72px",flexShrink:0}}>{opp.company}</span>
                  <span style={{fontSize:"12px",fontWeight:600,minWidth:"54px",textAlign:"right",flexShrink:0}}>R$ {(opp.value/1000).toFixed(0)}k</span>
                  <span style={{fontSize:"10px",padding:"2px 7px",borderRadius:"8px",background:PRI_BG[opp.priority],color:PRI_TXT[opp.priority],flexShrink:0}}>{opp.priority}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── FOLLOW-UPS ── */}
        {view==="tasks" && (
          <div style={{flex:1}}>
            <div style={S.card}>
              <div style={{fontSize:"12px",fontWeight:600,marginBottom:"12px"}}>Follow-ups por data</div>
              {[...opps].filter(o=>o.nextAction).sort((a,b)=>(a.nextDate||"9999")>(b.nextDate||"9999")?1:-1).map(opp=>{
                const late = opp.nextDate && opp.nextDate<today;
                const stg  = STAGES.find(s=>s.id===opp.stage);
                return (
                  <div key={opp.id} onClick={()=>{setSel(opp);setView("kanban");}} style={{display:"flex",gap:"12px",padding:"10px 0",borderBottom:"1px solid #f0f0f0",cursor:"pointer",alignItems:"flex-start"}}>
                    <div style={{minWidth:"74px",fontSize:"11px",color:late?"#E24B4A":"#aaa",fontWeight:late?600:400}}>{opp.nextDate||"—"}</div>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:"12px",fontWeight:600,marginBottom:"2px"}}>{opp.nextAction}</div>
                      <div style={{fontSize:"11px",color:"#888"}}>{opp.company} · {opp.title}</div>
                    </div>
                    <span style={{fontSize:"10px",padding:"2px 7px",borderRadius:"8px",background:stg?.color+"22",color:stg?.color,fontWeight:600,flexShrink:0}}>{stg?.tag}</span>
                    <span style={{fontSize:"10px",padding:"2px 7px",borderRadius:"8px",background:PRI_BG[opp.priority],color:PRI_TXT[opp.priority],flexShrink:0}}>{opp.priority}</span>
                  </div>
                );
              })}
              {opps.filter(o=>o.nextAction).length===0 && <div style={{fontSize:"13px",color:"#aaa",textAlign:"center",padding:"20px 0"}}>Nenhum follow-up cadastrado</div>}
            </div>
          </div>
        )}

        {/* ── PAINEL DETALHE ── */}
        {sel && (
          <div style={{width:"272px",flexShrink:0,...S.card,position:"sticky",top:"60px"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:"10px"}}>
              <div style={{flex:1,paddingRight:"8px"}}>
                <div style={{fontSize:"13px",fontWeight:600,marginBottom:"2px",lineHeight:1.3}}>{sel.title}</div>
                <div style={{fontSize:"11px",color:"#888"}}>{sel.company} · {sel.contact}</div>
              </div>
              <button onClick={()=>setSel(null)} style={{background:"none",border:"none",cursor:"pointer",color:"#aaa",fontSize:"16px",lineHeight:1,padding:0,flexShrink:0}}>✕</button>
            </div>
            <div style={{display:"flex",gap:"5px",flexWrap:"wrap",marginBottom:"10px"}}>
              <span style={{fontSize:"11px",padding:"2px 8px",borderRadius:"10px",background:"#E6F1FB",color:"#0C447C",fontWeight:600}}>R$ {(sel.value||0).toLocaleString("pt-BR")}</span>
              <span style={{fontSize:"11px",padding:"2px 8px",borderRadius:"10px",background:PRI_BG[sel.priority],color:PRI_TXT[sel.priority],fontWeight:600}}>{sel.priority}</span>
              <span style={{fontSize:"11px",padding:"2px 8px",borderRadius:"10px",background:(STAGES.find(s=>s.id===sel.stage)?.color||"#888")+"22",color:STAGES.find(s=>s.id===sel.stage)?.color,fontWeight:600}}>{STAGES.find(s=>s.id===sel.stage)?.label}</span>
            </div>
            <div style={{display:"flex",gap:"5px",marginBottom:"12px"}}>
              <button onClick={()=>move(sel.id,-1)} style={{flex:1,padding:"5px",fontSize:"11px",borderRadius:"6px",border:"1px solid #ddd",background:"transparent",cursor:"pointer",color:"#666"}}>← Recuar</button>
              <button onClick={()=>move(sel.id,1)} style={{flex:1,padding:"5px",fontSize:"11px",borderRadius:"6px",border:"1px solid #0F6E56",background:"#E1F5EE",cursor:"pointer",color:"#085041",fontWeight:600}}>Avançar →</button>
            </div>
            {[
              {label:"Próxima ação", key:"nextAction", type:"textarea"},
              {label:"Data do follow-up", key:"nextDate", type:"date"},
              {label:"Valor R$", key:"value", type:"number"},
              {label:"Notas", key:"notes", type:"textarea"},
            ].map(f=>(
              <div key={f.key} style={{marginBottom:"8px"}}>
                <div style={S.label}>{f.label}</div>
                {f.type==="textarea"
                  ? <textarea value={sel[f.key]||""} onChange={e=>updateOpp({...sel,[f.key]:e.target.value})} style={{...S.input,resize:"none",height:f.key==="notes"?"72px":"48px"}}/>
                  : <input type={f.type} value={sel[f.key]||""} onChange={e=>updateOpp({...sel,[f.key]:f.type==="number"?Number(e.target.value):e.target.value})} style={S.input}/>
                }
              </div>
            ))}
            <div style={{marginBottom:"10px"}}>
              <div style={S.label}>Prioridade</div>
              <div style={{display:"flex",gap:"4px"}}>
                {["alta","media","baixa"].map(p=>(
                  <button key={p} onClick={()=>updateOpp({...sel,priority:p})} style={{flex:1,padding:"5px",fontSize:"11px",borderRadius:"6px",border:`1px solid ${sel.priority===p?PRI_TXT[p]:"#ddd"}`,background:sel.priority===p?PRI_BG[p]:"transparent",color:sel.priority===p?PRI_TXT[p]:"#888",cursor:"pointer",fontWeight:sel.priority===p?600:400,textTransform:"capitalize"}}>{p}</button>
                ))}
              </div>
            </div>
            <div style={{display:"flex",gap:"5px"}}>
              <button onClick={()=>openAI(`Analise a oportunidade "${sel.title}" da ${sel.company} na etapa ${STAGES.find(s=>s.id===sel.stage)?.label}. Próximos passos com 3S+M?`)} style={{flex:1,padding:"7px",fontSize:"11px",borderRadius:"6px",border:"1px solid #534AB7",background:"#EEEDFE",color:"#3C3489",cursor:"pointer",fontWeight:600}}>Analisar com IA</button>
              <button onClick={()=>delOpp(sel.id)} style={{padding:"7px 10px",fontSize:"11px",borderRadius:"6px",border:"1px solid #E24B4A",background:"#FCEBEB",color:"#791F1F",cursor:"pointer"}}>Excluir</button>
            </div>
          </div>
        )}
      </div>

      {/* ── PAINEL IA ── */}
      {aiOpen && (
        <div style={{position:"fixed",bottom:0,right:"16px",width:"330px",background:"#fff",border:"1px solid #e8e8e8",borderRadius:"12px 12px 0 0",display:"flex",flexDirection:"column",maxHeight:"480px",boxShadow:"0 -4px 20px rgba(0,0,0,0.08)",zIndex:100}}>
          <div style={{padding:"10px 14px",borderBottom:"1px solid #f0f0f0",display:"flex",alignItems:"center",gap:"8px",flexShrink:0}}>
            <div style={{width:"24px",height:"24px",borderRadius:"50%",background:"#534AB7",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"10px",color:"#fff",fontWeight:600,flexShrink:0}}>IA</div>
            <span style={{fontSize:"13px",fontWeight:600,flex:1}}>Gestor IA · 3S+M</span>
            {sel && <span style={{fontSize:"11px",color:"#aaa",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:"80px"}}>{sel.company}</span>}
            <button onClick={()=>setAiOpen(false)} style={{background:"none",border:"none",cursor:"pointer",color:"#aaa",fontSize:"16px",lineHeight:1}}>✕</button>
          </div>
          <div style={{flex:1,overflowY:"auto",padding:"12px",display:"flex",flexDirection:"column",gap:"8px"}}>
            {aiMsgs.map((m,i)=>(
              <div key={i} style={{display:"flex",justifyContent:m.role==="user"?"flex-end":"flex-start"}}>
                <div style={{maxWidth:"88%",padding:"8px 11px",borderRadius:m.role==="user"?"10px 10px 0 10px":"10px 10px 10px 0",background:m.role==="user"?"#E6F1FB":"#f5f5f3",fontSize:"12px",lineHeight:1.55,color:m.role==="user"?"#0C447C":"#1a1a1a",whiteSpace:"pre-wrap"}}>{m.content}</div>
              </div>
            ))}
            {aiLoading && <div style={{display:"flex"}}><div style={{padding:"8px 12px",borderRadius:"10px 10px 10px 0",background:"#f5f5f3",fontSize:"12px",color:"#888"}}>Analisando...</div></div>}
            <div ref={aiEnd}/>
          </div>
          <div style={{padding:"6px 8px 4px",borderTop:"1px solid #f0f0f0",display:"flex",flexWrap:"wrap",gap:"4px",flexShrink:0}}>
            {["Próximo passo 3S+M","Argumento NOMUDA","Plano 5W2H","Kaizen para este cliente","Risco de perda"].map(q=>(
              <button key={q} onClick={()=>chat(q)} style={{fontSize:"10px",padding:"3px 8px",borderRadius:"10px",border:"1px solid #e8e8e8",background:"transparent",cursor:"pointer",color:"#666"}}>{q}</button>
            ))}
          </div>
          <div style={{padding:"6px 8px 8px",display:"flex",gap:"6px",flexShrink:0}}>
            <input value={aiInput} onChange={e=>setAiInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&!e.shiftKey&&chat()} placeholder="Pergunte ao gestor IA..." style={{flex:1,fontSize:"12px",padding:"7px 10px",borderRadius:"6px",border:"1px solid #ddd",background:"#fafafa"}}/>
            <button onClick={()=>chat()} disabled={aiLoading} style={{padding:"7px 14px",fontSize:"13px",borderRadius:"6px",border:"none",background:aiLoading?"#CECBF6":"#534AB7",color:aiLoading?"#534AB7":"#fff",cursor:aiLoading?"default":"pointer",fontWeight:600}}>→</button>
          </div>
        </div>
      )}

      {/* ── MODAL API KEY ── */}
      {showKey && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.35)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200}}>
          <div style={{background:"#fff",borderRadius:"12px",border:"1px solid #e8e8e8",padding:"20px",width:"380px",maxWidth:"90vw"}}>
            <div style={{fontSize:"14px",fontWeight:600,marginBottom:"8px"}}>Chave da API Anthropic</div>
            <p style={{fontSize:"12px",color:"#666",marginBottom:"14px",lineHeight:1.6}}>Para usar o Gestor IA, você precisa de uma chave da API Anthropic. Obtenha em <a href="https://console.anthropic.com" target="_blank" style={{color:"#185FA5"}}>console.anthropic.com</a>. A chave fica salva apenas no seu navegador.</p>
            <div style={{marginBottom:"12px"}}>
              <div style={{fontSize:"11px",color:"#888",marginBottom:"4px"}}>API Key (começa com sk-ant-...)</div>
              <input type="password" value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="sk-ant-..." style={{width:"100%",fontSize:"13px",padding:"8px 10px",borderRadius:"6px",border:"1px solid #ddd",background:"#fafafa",boxSizing:"border-box"}}/>
            </div>
            <div style={{display:"flex",gap:"8px"}}>
              <button onClick={()=>{saveKey(apiKey);setShowKey(false);}} style={{flex:1,padding:"9px",fontSize:"13px",borderRadius:"6px",border:"none",background:"#185FA5",color:"#fff",cursor:"pointer",fontWeight:600}}>Salvar</button>
              <button onClick={()=>setShowKey(false)} style={{padding:"9px 16px",fontSize:"13px",borderRadius:"6px",border:"1px solid #ddd",background:"transparent",cursor:"pointer"}}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* ── MODAL NOVA OPORTUNIDADE ── */}
      {newModal && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.3)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:50,padding:"16px"}}>
          <div style={{background:"#fff",borderRadius:"12px",border:"1px solid #e8e8e8",padding:"18px",width:"360px",maxWidth:"100%",maxHeight:"90vh",overflowY:"auto"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"14px"}}>
              <span style={{fontSize:"14px",fontWeight:600}}>Nova oportunidade</span>
              <button onClick={()=>setNewModal(false)} style={{background:"none",border:"none",cursor:"pointer",color:"#aaa",fontSize:"16px"}}>✕</button>
            </div>
            {[
              {l:"Título / produto *",   k:"title",      t:"text"},
              {l:"Empresa *",            k:"company",    t:"text"},
              {l:"Contato / decisor",    k:"contact",    t:"text"},
              {l:"Valor estimado R$",    k:"value",      t:"number"},
              {l:"Próxima ação",         k:"nextAction", t:"text"},
              {l:"Data do follow-up",    k:"nextDate",   t:"date"},
            ].map(f=>(
              <div key={f.k} style={{marginBottom:"8px"}}>
                <div style={S.label}>{f.l}</div>
                <input type={f.t} value={form[f.k]} onChange={e=>setForm({...form,[f.k]:e.target.value})} style={S.input}/>
              </div>
            ))}
            <div style={{marginBottom:"8px"}}>
              <div style={S.label}>Notas</div>
              <textarea value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} style={{...S.input,resize:"none",height:"60px"}}/>
            </div>
            <div style={{display:"flex",gap:"8px",marginBottom:"12px"}}>
              <div style={{flex:1}}>
                <div style={S.label}>Etapa inicial</div>
                <select value={form.stage} onChange={e=>setForm({...form,stage:e.target.value})} style={{...S.input}}>
                  {STAGES.map(s=><option key={s.id} value={s.id}>{s.label}</option>)}
                </select>
              </div>
              <div style={{flex:1}}>
                <div style={S.label}>Prioridade</div>
                <select value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})} style={{...S.input}}>
                  <option value="alta">Alta</option>
                  <option value="media">Média</option>
                  <option value="baixa">Baixa</option>
                </select>
              </div>
            </div>
            <button onClick={addOpp} disabled={!form.title||!form.company} style={{width:"100%",padding:"10px",fontSize:"13px",borderRadius:"6px",border:"none",background:form.title&&form.company?"#0F6E56":"#9FE1CB",color:"#fff",cursor:form.title&&form.company?"pointer":"default",fontWeight:600}}>
              Criar oportunidade
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
